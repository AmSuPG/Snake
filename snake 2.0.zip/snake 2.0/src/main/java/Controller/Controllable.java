/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Controller;

import java.awt.Graphics2D;

/**
 *
 * @author Esteban
 */
public interface Controllable {
    public static void start(){
        
    };
    public static void repaintDrawables(Graphics2D drawer){
        
    };
    public static void revise(){
        
    };
    public static void dead(int x,int y){
        
    };
    
}
