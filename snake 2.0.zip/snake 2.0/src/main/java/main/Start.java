/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import Controller.ControllerAdapter;
import Controller.GlobalController;

/**
 *
 * @author Estudiantes
 */
public class Start {
    public static void main(String[] args) {
        ControllerAdapter.start();
        GlobalController.start();
        
        
    }
   
}
