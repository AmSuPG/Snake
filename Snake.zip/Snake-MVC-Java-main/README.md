# Snake-MVC-Java
Juego de snake con obstaculos en Java utilizando patron modelo-vista-controlador
